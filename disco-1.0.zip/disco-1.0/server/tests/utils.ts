import { Server } from 'node:http'

import { client, Task } from '@epfml/discojs'

import { getApp } from '../src/get_server'

// port to start server on
const PORT: number | undefined = 5555

export async function startServer (): Promise<Server> {
  const app = await getApp()

  const server = app.listen(PORT)

  await new Promise((resolve, reject) => {
    server.once('listening', resolve)
    server.once('error', reject)
  })

  return server
}

export async function getClient<T extends client.Base> (
  Constructor: new (url: URL, t: Task) => T,
  server: Server,
  task: Task
): Promise<T> {
  let host: string
  const addr = server?.address()
  if (addr === undefined || addr === null) {
    throw new Error('server not started')
  } else if (typeof addr === 'string') {
    host = addr
  } else {
    if (addr.family === '4') {
      host = `${addr.address}:${addr.port}`
    } else {
      host = `[${addr.address}]:${addr.port}`
    }
  }
  const url = new URL(`http://${host}`)
  return new Constructor(url, task)
}
