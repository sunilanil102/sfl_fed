import { tf } from '@epfml/discojs'

export type Weights = tf.Tensor[]
