module.exports = {
  locales: [
    {
      name: 'english',
      file: 'default.json'
    }
  ],
  default: {
    name: 'default',
    file: 'default.json'
  },
  locale: 'english'
}
