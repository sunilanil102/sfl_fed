#!/bin/bash

# NOTE: make sure you have peerjs installed
# npm install peer -g

peerjs --port 9000 --key peerjs --path /myapp
