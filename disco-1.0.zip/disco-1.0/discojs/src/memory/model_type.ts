// Type of model to store & retrieve
export enum ModelType {
  WORKING = 'working',
  SAVED = 'saved'
}
