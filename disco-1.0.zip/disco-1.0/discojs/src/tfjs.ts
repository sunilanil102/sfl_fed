import * as tf from '@tensorflow/tfjs'

export { tf }
