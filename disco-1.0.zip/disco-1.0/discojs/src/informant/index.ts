export { GraphInformant } from './graph_informant'
export { Base as TrainingInformant } from './training_informant'
export * as informant from './training_informant'
