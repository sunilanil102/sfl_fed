export { Base } from './base'

export { FederatedInformant } from './federated'
export { DecentralizedInformant } from './decentralized'
export { LocalInformant } from './local'
