/* eslint-disable no-unused-vars */
export enum TrainingSchemes {
  LOCAL = 'local',
  DECENTRALIZED = 'deai',
  FEDERATED = 'feai'
}
